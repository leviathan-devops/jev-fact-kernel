#!/usr/bin/env python3
"""systemone-server.py — the TypeSafe /v1/systemone endpoint for JevK5 on llama.cpp.

WHY THIS EXISTS
  The jevk5 package ships two runtimes and ONE server:
    JevK5      (runtime.py)  torch + transformers, device="cuda", bfloat16 -> ~9 GB VRAM
    JevK5GGUF  (gguf.py)     stdlib only, POSTs /tokenize + /completion to a llama-server
    jevk5-serve (server.py)  hardcodes `model = JevK5(args.model)` -> the CUDA runtime only
  On this host the CUDA runtime cannot fit (9,216 MiB bf16 vs 45 MiB free), so the
  GGUF runtime is the only viable path. But `jevk5-serve` has no --gguf flag.
  This server is that missing flag: the SAME request/response contract as
  jevk5/server.py, backed by the package's own JevK5GGUF client.

CONTRACT (identical to jevk5/server.py)
  POST /v1/systemone
    {"state": "...", "questions": {"<id>": {"type": "noul|choice|score",
                                            "instructions": "...",
                                            "criteria": ...}}}
  -> {"model", "answers": {"<id>": {type, confidence, noul|choice|probabilities, ...}},
      "usage": {"input_tokens", "output_tokens": 0}, "latency_ms"}
  GET /health -> {"ok": true, "model": ...}

The readout is the package's own: its prompt builder, its LETTERS, its temperature
(default 1.532), its renormalisation. Nothing here re-implements the protocol.
"""

from __future__ import annotations

import argparse
import json
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from jevk5 import JevK5GGUF

# `normalized` is copied VERBATIM from jevk5/server.py:22-34. It is imported from there
# in the upstream package, but that module does `from jevk5.runtime import JevK5`, which
# drags in torch+numpy. The GGUF path is stdlib-only by design (see gguf.py's docstring),
# so importing it would break the very path we need. Copied, not re-implemented — the
# READOUT (prompt + LETTERS + temperature + logprob handling) still comes from the package.
def normalized(question: dict) -> dict:
    if question.get("type") not in ("noul", "choice", "score"):
        raise ValueError(f"unknown question type {question.get('type')!r}")
    if "instructions" not in question:
        raise ValueError("question is missing instructions")
    criteria = question.get("criteria")
    if question["type"] == "choice":
        if isinstance(criteria, list):
            criteria = dict.fromkeys(criteria)
        if not isinstance(criteria, dict) or len(criteria) < 2:
            raise ValueError("choice criteria must name at least two options")
    if question["type"] == "score" and (not isinstance(criteria, list) or len(criteria) < 2):
        raise ValueError("score criteria must list at least two levels")
    return {**question, "criteria": criteria}


def make_handler(model: JevK5GGUF, name: str):
    lock = threading.Lock()

    class Handler(BaseHTTPRequestHandler):
        def _send(self, status: int, payload: dict) -> None:
            data = json.dumps(payload).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self) -> None:
            if self.path.rstrip("/") == "/health":
                self._send(200, {"ok": True, "model": name, "runtime": "gguf"})
            else:
                self._send(404, {"error": "not found"})

        def do_POST(self) -> None:
            if self.path.rstrip("/") != "/v1/systemone":
                self._send(404, {"error": "not found"})
                return
            started = time.perf_counter()
            try:
                body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
                with lock:  # one GPU, one model: serialise, as the package does
                    answers = {
                        qid: model.decide(body["state"], normalized(q))
                        for qid, q in body["questions"].items()
                    }
            except (ValueError, KeyError, TypeError) as error:
                self._send(400, {"error": str(error)})
                return
            tokens = sum(a.pop("input_tokens", 0) for a in answers.values())
            self._send(200, {
                "model": body.get("model") or name,
                "answers": answers,
                "usage": {"input_tokens": tokens, "output_tokens": 0},
                "latency_ms": round((time.perf_counter() - started) * 1e3, 2),
            })

        def log_message(self, *args) -> None:
            pass

    return Handler


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="TypeSafe /v1/systemone for JevK5 on llama.cpp")
    p.add_argument("--llama", default="http://127.0.0.1:8008",
                   help="the llama-server serving the JevK5 GGUF (the engine)")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8090)
    p.add_argument("--name", default="jevk5-4b-v0.2-Q8_0")
    args = p.parse_args(argv)

    model = JevK5GGUF(args.llama)
    server = ThreadingHTTPServer((args.host, args.port), make_handler(model, args.name))
    print(f"serving {args.name} on http://{args.host}:{args.port}/v1/systemone", flush=True)
    print(f"  engine: llama-server at {args.llama}", flush=True)
    print(f"  temperature: {model.temperature}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
