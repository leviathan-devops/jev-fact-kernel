---
name: jevgrep-local-jev-wiring
description: "Install the jevgrep CLI (jg) on this host and point it at the LOCAL JevK5 decision model instead of a hosted provider — the custom-endpoint auth, the /systemone path-append rule, the choice between the two systemone endpoints, and the measured concurrency/timeout limits. Use when installing/repairing jevgrep, when jg doctor fails, when jg searches error with 'Request timed out after 15000 ms', or when asked to wire any TypeSafe-format client to the local jevk5."
---

# jevgrep → local JevK5 wiring

Wires the `jg` CLI (github.com/dzhng/jevgrep, PyPI `@dzhng/jevgrep`) to the LOCAL JevK5-4B instead of a hosted provider. The upstream chain (JevK5 GGUF → systemone adapter → JM) is owned by the `beacon-local-jev-wiring` skill — this skill covers only what is jevgrep-specific and **cross-references** that chain rather than restating it.

## 0 · THE TWO ENDPOINTS (pick :8090)

| endpoint | what | concurrency | verdict |
|---|---|---|---|
| `:8090` | canonical, systemd `jevk5-systemone.service`, `/home/leviathan/jevk5-runtime/systemone-server.py`, direct-to-llama | **ThreadingHTTPServer** | **USE THIS** |
| `:7778` | `JevManager/serve-systemone.ts` (JM-mediated: adapter → `:7777/decide` → `:8008`) | serializes through JM | fallback only |
| `:8008` | raw JevK5 llama-server (`~/models/servers/jevk5.sh`, `-np 1` = ONE GPU slot, `-c 16384`, beellama, f16 KV) | 1 slot | the GPU backend, never dialled by `jg` |

Both endpoints answer the same TypeSafe shape `{state, questions}` → `{model, answers{…{type:"noul",noul:0.xx}}, usage}`. `:8090` returns `latency_ms`; `:7778` derives `usage.input_tokens` from JM's `cost_usd`. Prefer `:8090` — it is threaded, so parallel judge calls queue on the GPU instead of on a single JS event loop.

## 1 · INSTALL

```sh
npm install -g @dzhng/jevgrep@latest     # needs Node 22+ (host has v24)
jg --version                             # 0.7.0 measured
```

Install the agent skill separately — the CLI does not teach an agent to use it:
```sh
jg skill                                 # delegates to `npx skills add dzhng/jevgrep --skill jevgrep`
```

## 2 · THE WIRE (the one command)

```sh
printf 'local' | jg auth --provider custom --base-url http://127.0.0.1:8090/v1 --model jevk5-4b --stdin
jg doctor
```

**THE PATH-APPEND RULE (the thing that bites):** jevgrep appends `/systemone` to the base URL. So `--base-url http://127.0.0.1:8090/v1` produces the request `POST http://127.0.0.1:8090/v1/systemone` — exactly what the adapter serves. Do NOT pass `/v1/systemone` in the base URL (URL suffixes would consume the appended path).

**Validation rules** (from `packages/core/src/providers.ts::validateBaseURL`): `https://` required EXCEPT `http://localhost` and `http://127.0.0.1` are allowed for a local proxy. No credentials, no query string, no fragment. Model must be one non-empty ID with no whitespace.

**Credentials** land at `~/.config/jevgrep/credentials.json` (`{provider:"custom", baseURL, model, apiKey}`), owner-only. Env-var overrides are IGNORED — auth must run. Re-running `auth` replaces the record.

**Presets exist** (`vercel` / `typesafe` / `openrouter` / `opencode`) — but only `custom` reaches `:8090`. The presets point at hosted TypeSafe/OpenRouter/OpenCode-Zen.

## 3 · VERIFY (three rungs, cheapest first)

```sh
jg doctor                                     # "Jev connection verified through Custom endpoint (127.0.0.1:8090)."
jg files <root>                               # file inventory — NO provider requests, no credentials needed
jg "How does the judge select a key?" <root>  # a real search
```

The adapter request shape `jg` sends (boolean `noul` WITHOUT `criteria`) — usable as a hand probe:
```sh
curl -s -X POST http://127.0.0.1:8090/v1/systemone -H 'Content-Type: application/json' \
  -d '{"state":{"c":"<candidate text>"},"questions":{"q":{"type":"noul","instructions":"relevant?","true":"yes","false":"no"}}}'
```

## 4 · THE MEASURED LIMITS (set expectations, do not promise what the GPU cannot do)

- **Cache hides the true cost.** A repeated identical `state` returns in ~3 ms (JM/adapter cache). The REAL cache-miss cost is **~0.5–0.9 s per judge call** on the RTX 4080 Laptop (`-np 1`).
- **Concurrency:** 32 *unique* calls with a small payload = **2,668 ms** wall (threaded adapter, good). 32 *unique* calls with a realistic ~5.7 KB state (a source excerpt) = **>25 s** — the tail blows past jevgrep's **15,000 ms per-request timeout** ("max concurrent requests: 32").
- **The fix is to narrow the root, not to raise the timeout.** `jg` has no concurrency flag; the lever is scope:
  `jg "<question>" <narrow/subdir>` and `--exclude 'src/generated/'`. Pass the SAME root + filters to `jg files` and the search.
- **Partial failure is normal and reported honestly:** the run prints `"provider": N` (N = timed-out calls) and still lists the files that answered. Treat a non-zero `provider` as a degraded run, not a clean one (RULES.md #2).

## 5 · FAILURE BRANCHES (symptom → action)

| symptom | action |
|---|---|
| `jg doctor` → connection error | the endpoint is down. `systemctl status jevk5-engine.service jevk5-systemone.service`; `curl -sf http://127.0.0.1:8090/health` (expect 200). |
| `jg doctor` → HTTP 4xx with a body | the request REACHED the adapter — it is a payload/schema problem, not connectivity. Read the adapter's named error (`JM_SYS_*` codes). |
| `"provider": N` with N>0 | a degraded run; narrow the root. Do NOT retry the same scope. |
| `Request timed out after 15000 ms` | you asked for more unique judges than the single GPU slot can serve in 15 s. Narrow the root. |
| `jg` returns 0 files | scope too narrow OR `jg files <root>` shows nothing — widen the root; the search is not broken. |
| auth saved but `jg` still uses the old endpoint | re-run `auth`; env vars are ignored by design and the saved record wins. |

## 6 · ADVERSARIAL-FIRST TEST SET (the answers are knowable)

- **Cache-miss latency:** two DIFFERENT `state` values back-to-back must both take ~0.5–0.9 s, not ~3 ms. Identical states hitting ~3 ms is the cache, not the model — a "fast" result on a repeated probe is NOT evidence the GPU is that fast.
- **Timeout discrimination:** 8 unique realistic-payload calls must ALL return 200. If any hits the 15 s cap, the scope is too large for the deployment.
- **Route:** `POST :8090/anything-else` must NOT answer a decision (only `/v1/systemone`; the handler checks `self.path.rstrip('/') != '/v1/systemone'`). A "working" call on a wrong path is a false green.
- **Path-append:** the base URL must end such that `+ "/systemone"` lands on `/v1/systemone`. Assert with a hand `curl` before blaming `jg`.
- **Empty answers:** a `state` outside the model's competence must still return a `noul` probability (it is a binary readout, never a refusal) — do not read a 0.5 as "error".

## 7 · LIMITS (state up front)

- `jg` judges RELEVANCE of candidate files/excerpts — it is not a code generator, an LSP, and not a grep replacement. For exact strings use `grep`; for the call graph use `ripwire`/`graph-query`.
- The local model is **JevK5-4B** — a small decision model. It reads ~16 k tokens max (`-c 16384`); the adapter refuses oversized state rather than truncating silently.
- `jg` sends eligible SOURCE to the endpoint. Pointed at a local endpoint, nothing leaves the host; pointed at a hosted preset, it does.
- No offline/air-gapped mode beyond the local endpoint.
