---
name: jev-swe-regex-pile
description: "Program with TypeSafe Jev as a decision primitive: keep control flow in code; call systemOne only where if-on-strings would be a regex pile. Use when the operator asks how to use Jev, Jev vs agents/compilers, production System One, omp-jev-compaction, jev-mcp, or reprogramming SWE habits around Jev."
---

# Jev SWE — regex-pile insertion law

## The one law
Keep the workflow in code. Insert Jev only where `if` on strings would be a pile of regex (intent, synonyms, relevance, done-ness, keep/drop of tool JSON). Shape (parse, SQL, count, dates, hashes, HTTP status) stays in YOUR language.

Jev is System One: `state` + closed questions → Choice/Score/Noul + probabilities. Not an agent, compiler, GPU-renderer of pipelines, or thinking computer. Code owns branches and side effects.

## Regex-pile test
- Predicate is shape → parser/code.
- Predicate is meaning → list answers first, then `TypeSafeClient.systemOne`, then `if` on floats/labels.
- Cannot list answers → retrieve or LLM-generate candidates, THEN Jev picks (never invent options).

## Program
```
npm install @typesafe-ai/sdk
export TYPESAFE_API_KEY=...  # console.typesafe.ai/keys
```
```ts
import { choice, noul, TypeSafeClient } from "@typesafe-ai/sdk";
const client = new TypeSafeClient();
const r = await client.systemOne({
  state: { msg },
  questions: { cat: choice("ticket category", { billing: "money", tech: "breakage", other: "none" }) },
});
if (r.answers.cat.confidence < 0.5) return "human";
return r.answers.cat.choice;
```
Batch many independent questions on one state. Filter state in code first. Fail closed on missing key / 401 / malformed distro.

## Accuracy
Calibration is group frequency (p=0.8 happens ~80% of the time), not one call. `confidence` = peakedness, not P(correct). Noul 0.5 = yes≈no. Do not ask Jev to count, do math, compare dates, or generate text (jev-1.13 jaggedness).

## Community “in-session copilot” (not chatting with Jev)
1. OMP compaction hook: `omp plugin install jerryfane/omp-jev-compaction` (or Claude `tamaratran/fast-jev-compaction`). Key in env or `~/.config/typesafe/key`.
2. MCP: `npx -y jev-mcp` — `jev_classify` / `jev_score` / `jev_check` / `jev_ask`.
3. Skill to write Jev code: `npx skills add typesafe-ai/skills --skill typesafe-ai`.
4. Foreman (`thruwire/foreman`) is a sidecar over Codex, not in-transcript.

JDM/Discord manager is unrelated I/O. Do not merge Jev with Puffer angels.

## This workspace notes
Bibles: `JARVIS/reports/JevSWE_Bible_ShowMe_v2.md`, `JARVIS/reports/JevOmpCopilot_Master_Blueprint_v1.md`. Attach/hardSteer exist; a Jev desk-supervisor tick is PROPOSED until TYPESAFE_API_KEY exists.
