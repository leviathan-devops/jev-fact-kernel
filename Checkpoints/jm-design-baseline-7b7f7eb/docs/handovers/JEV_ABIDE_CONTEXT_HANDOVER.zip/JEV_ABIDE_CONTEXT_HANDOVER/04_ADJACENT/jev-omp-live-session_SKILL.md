---
name: jev-omp-live-session
description: "Wire TypeSafe Jev into a live OMP (or Claude Code) agent session the way the community actually does: compaction plugin, MCP tools, or official skill—not Foreman architecture. Use when the operator asks how to use Jev as an in-session copilot, how X posts mean Jev in Claude/OMP, or how to install omp-jev-compaction / jev-mcp / typesafe-ai skill."
---

# Jev in a live agent session (community wiring)

Do not lecture System One vs LLM. Do not default to Foreman-on-attachDesk unless they asked for a sidecar supervisor.

## What the X posts mean

Four real patterns (primary sources 2026-09-19):

| Pattern | Live session | Install |
|---|---|---|
| Compaction/context hook | Jev never talks; prunes stale tool dumps; text verbatim | OMP: `omp plugin install jerryfane/omp-jev-compaction`. Claude: tamaratran/fast-jev-compaction |
| MCP tools | Agent calls `jev_classify` / `jev_score` / `jev_check` / `jev_ask` | rashedInt32/jev-mcp |
| Official skill | Teaches writing Jev *code*; slash invoke; not every turn | `npx skills add typesafe-ai/skills --skill typesafe-ai` |
| Foreman sidecar | Outside transcript, watches Codex | thruwire/foreman — only if they asked sidecar |

JARVIS Discord Manager is unrelated.

## OMP compaction (default “copilot in session”)

1. Key from https://console.typesafe.ai/keys
2. `mkdir -p ~/.config/typesafe && printf '%s' 'ts_...' > ~/.config/typesafe/key && chmod 600 ~/.config/typesafe/key`
3. Export in the env that **launches omp**: `export TYPESAFE_API_KEY=$(cat ~/.config/typesafe/key)`
4. `omp plugin install jerryfane/omp-jev-compaction` then `omp`
5. Off: `OMP_JEV_CONTEXT=0` or `omp plugin disable omp-jev-compaction`
6. Proof: `grep "jev context" ~/.omp/logs/omp.$(date +%F).*.log | tail -3`
7. Spill: `~/.omp/jev-spill/<hash>.txt` — agent `read`s dropped payloads

OpenRouter alt: `OPENROUTER_API_KEY` + `POST https://openrouter.ai/api/alpha/decisions` model `typesafe/jev-1.13`. TypeSafe key wins if both set.

## MCP (agent asks Jev mid-turn)

```bash
npx -y jev-mcp
```

Key: `TYPESAFE_API_KEY` then `JEV_API_KEY` then `~/.config/typesafe/key`. Never a tool argument.

Prefer `jev_ask` (batch). Do not ask Jev to compute/count.

## Write Jev into product code

```sh
npm install @typesafe-ai/sdk
export TYPESAFE_API_KEY=...
```

```ts
import { choice, TypeSafeClient } from "@typesafe-ai/sdk";
const client = new TypeSafeClient();
const response = await client.systemOne({
  state: { document: "..." },
  questions: { category: choice("What is this about?", { a: null, b: null }) },
});
```

Docs: https://docs.typesafe.ai/sdk/javascript.md and https://docs.typesafe.ai/agent-skill.md

## Cite dump

`JARVIS_DISCORD/reports/JEV_LIVE_SESSION_COMMUNITY.md`
