---
name: ttsr-data-extraction
description: "Extract TTSR behavioral data from agent failures and derailments as they happen — backwards-engineer the root cause from reasoning-token patterns, log it, propose the TTSR rule that catches it mid-stream next time"
---

# TTSR-Data — Extract Behavioral Failure Data For TTSR Rule Development

## THE PURPOSE

When the agent does something stupid — writes "I haven't read X" instead of reading X, summarizes when FULL was ordered, stubs a receipt, asks permission instead of executing — the failure is DATA. The reasoning tokens that led to the derailment contain the SOURCE PATTERN. Extract it, name it, log it, propose the TTSR condition.

## THE PROCEDURE (5 steps, no skips)

### STEP 1 — IDENTIFY THE DERAILMENT CLASS

| Class | Example |
|---|---|
| Consultation-posture | Wrote "I haven't read X" instead of reading X |
| Watering-down | Summarized when FULL was explicitly ordered |
| Premature-done | Claimed "it works" without receipts |
| Scope-shrink | Proposed "simpler approach" instead of full scope |
| Permission-ask | Asked "should I continue?" instead of executing |
| Stubbing | Presented truncated receipt as proof |
| Wrong-system | Traced the wrong repo/system/source |
| Generic-garbage | Gave "top 10 tools" without repo/pin/receipt |
| Debate-instead-of-execute | Researched options after a direct imperative |
| Assumption-design | Designed with assumptions instead of reading the source |
| Half-adopt | Executed partially, analyzed instead of completing |
| Narration-theater | Described what it was about to do without doing it |

### STEP 2 — EXTRACT THE 4-STAGE REASONING PATTERN

1. THE TRIGGER: what context activated the derailment?
2. THE BRANCH: what fork did the reasoning take?
3. THE DERAILMENT: what did the agent do instead of the correct action?
4. THE CORRECT ACTION: what SHOULD the agent have done?

### STEP 3 — PROPOSE THE TTSR CONDITION

scope + condition regex + interruptMode + enforcement body. Must be word-bounded, phrase-level, negative-lookahead protected, calibrated from actual failure data.

### STEP 4 — LOG IN THE TTSR-DATA THREAD

bun /home/leviathan/JARVIS_WORKSPACE/OMP/threads/omp-threads.ts append ttsr-data "<class>: <description>" "ttsr-data,<class>" "<4-stage pattern + condition + meta-lesson>"

### STEP 5 — THE META-LESSON

One sentence for the next agent. This is the calibration data.

## LAWS

1. FIRST-HAND ONLY — extract from the actual failure this turn
2. THE REASONING IS THE DATA — behavior is symptom, reasoning pattern is disease
3. EVERY DERAILMENT IS A TTSR CANDIDATE
4. CALIBRATE FROM REAL FAILURES — not theoretical patterns
5. LOG IMMEDIATELY — data rots if not captured at moment of failure
