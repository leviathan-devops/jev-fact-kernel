---
name: ttsr-rule-authoring
description: "Author and debug TTSR behavioral-enforcement rules on OMP (this host): warhead-class rule files, scope/interrupt semantics, the silent-death traps, and the verification protocol"
---

# TTSR Rule Authoring + OMP Behavioral Enforcement

Use when porting behavioral law (warheads, derailment bans, code-shape floors) into OMP via TTSR rules, or debugging "rule never fires" on this host.

## The mechanism (30 seconds)
TTSR = mid-stream enforcement. Conditions (regex or ast-grep) evaluated per stream delta on ISOLATED buffers (text / thinking / toolcall:<id>). On match + interrupt: abort mid-token → `contextMode:discard` REMOVES the violating partial from history → rule body injected as hidden `<system-interrupt>` → `agent.continue()` retries. Survives compaction via `injectedTtsrRules`.

## Rule file
`<project>/.omp/rules/*.md` (walking up) or `~/.omp/agent/rules/*.md` (user). Frontmatter: `condition` (string|array), `astCondition` (edit/write tool streams only, language from extension), `scope`, `interruptMode` (never|prose-only|tool-only|always), `globs`, `alwaysApply`. Body = injected enforcement text.

## Scope grammar (STRICT — the parser accepts ONLY these)
`text`, `thinking`, `tool`, `tool:<name>`, `tool:<name>(<glob>)`, bare tool name. NO `agent:` token — per-agent rules do not exist; differentiate via worktree `.omp/rules/`.

## The 5 silent-death traps (all measured on this host)
1. `thinking` is OFF by default — omit it from scope and reasoning streams are never matched.
2. Rules load at session START — a new file needs an omp restart. No hot-load.
3. `repeatMode: once` (host default) fires each rule once per session; use `after-gap` + `repeatGap` for persistent pressure.
4. Invalid regex = condition silently skipped → zero conditions → rule rejected at addRule. Always verify.
5. AST conditions never fire on prose/thinking — tool streams with a file language only.

## Verification protocol (never skip)
1. `omp ttsr test '<phrase>' --source thinking --agent task [-r rule.md]` — proves the DETECTOR.
2. Restart omp — binds the rule.
3. Fire a trap prompt live — only a live abort proves the interrupt path end to end.

## Wiring anchors (vendored @oh-my-pi/pi-coding-agent)
- Manager: `src/export/ttsr.ts` (590L) — registration gates, scope compile, buffers, matching, repeat gates.
- Coordinator: `src/session/ttsr-coordinator.ts` (496L) — tool-context contract (matcherPaths → path-args scan → 4 path candidates + basename fallback), matcherDigest preference (write tool exposes REAL file content), `#handleMatches` (the 50ms deferred injection, retry-token guards, tool-scoped aborts).
- Classifier: `src/capability/rule-buckets.ts` — condition→TTSR bucket (enforces), alwaysApply→context, else→rulebook.
- Session wiring: `sdk.ts:1524-1548` (load+bucket+restoreInjected), `agent-session.ts:2504` (checkMessageUpdate on every delta).

## Prompt law vs TTSR (compose, never substitute)
SYSTEM.md / agent bodies / APPEND_SYSTEM.md carry DOCTRINE (what + why). TTSR carries DETECTORS (banned phrase-classes, code shapes, hard floors). The warhead shape: prompt law in `~/.omp/agent/SYSTEM.md` + agent bodies; detectors in `.omp/rules/` with the warhead text as the injected body.

## Full references on this host
- `Shared_Workspace/TTSR_ENGINE_EXTRACTED/TTSR_MASTER_REFERENCE.md` (1500L, 14 parts — the complete mechanics bible)
- `Shared_Workspace/TTSR_ENGINE_EXTRACTED/GOLDEN_REASONING.md` (11 decisions incl. the Paragon gap map)
- `Shared_Workspace/agent_plugin_boilerplates/ttsr-engine-boilerplate/` (46-test battery, host-seamed machinery, plug-and-play)

## Host state (2026-09-18)
`ttsr.enabled=true, interruptMode=always, repeatMode=once, repeatGap=10, contextMode=discard`. 27 builtin code-quality rules active, ZERO behavioral rules authored yet.
