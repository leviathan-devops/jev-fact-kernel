---
name: omp-warhead-enforcement-port
description: "Port Trident warheads into OMP as ENFORCED behavior: TTSR stream-abort rules + SYSTEM.md/agent-body appends. Use when operator wants trident warheads, derailment enforcement, or behavioral rules wired into OMP."
---

# OMP Warhead Enforcement Port

Port the Trident warhead set (source: `JARVIS_WORKSPACE/skills-store/skills/trident-warheads/SKILL.md`, 409L, 21 unique warheads) into OMP so derailment behavior is MECHANICALLY enforced, not just prompted.

## The three enforcement layers (install all three)

### Layer 1 — TTSR stream-abort rules (mechanical, strongest)
Rules live at `<cwd>/.omp/rules/*.md` (project walk-up) or `~/.omp/agent/rules/*.md` (user).
Rule file format:
```markdown
---
description: <when this fires>
condition: "\b(?:too big|scope[- ]shrink|should I continue\?|shall I proceed\?)\b"
scope: "source:thinking, source:text, agent:task, agent:scout, agent:sonic"
interruptMode: always
---
<reminder body — the warhead text injected on match>
```
- `condition`: JS regex, word-boundaried, evaluated incrementally on stream chunks (text, thinking, or tool args per `scope`).
- `astCondition`: ast-grep structural pattern (edit/write streams only).
- Buckets (rule-buckets.ts): condition→TTSR abort; alwaysApply→context; description-only→rulebook.
- Verify: `omp ttsr test '<trigger phrase>' --source thinking --agent task` must show the rule firing. `omp ttsr list` shows all active.
- Author ~12 rules mapping the warhead signature phrases (scope-shrink, approval-seeking, token-cost complaints, theatrical claims, prompt-rewrite spirals).

### Layer 2 — Prompt-level identity
- Main session: append trimmed warhead block to `~/.omp/agent/APPEND_SYSTEM.md` (appends; SYSTEM.md would REPLACE built-in).
- Subagents: append role-trimmed warhead block to each body in `~/.omp/agent/agents/{task,scout,sonic,security-reviewer}.md`. Body = entire subagent system prompt (executor.ts:3034-3049).
- Trim for OMP: drop W6 mimo TUI choreography (replace with: `/model` switch + proxy fallbackChains muse→mimo), drop W16/W22a wave-manager tool refs (OMP uses task batch + eval workpool), strip Poseidon/mimo naming, keep `.trident/` artifact paths as convention.
- Keep one canonical source; regenerate agent bodies from it.

### Layer 3 — trident-omp extension gates (optional, currently castrated)
Extension already loaded (config.yml extensions → ~/.omp/agent/extensions/trident-omp/dist.js, source OMP_WORKSPACE/trident-omp v2.0.0). Tool blocks + nag + poseidon-detect DISABLED by operator orders 2026-09-15/17 (src/index.ts:100-102). Re-enable = edit src + `bun build src/index.ts --outdir dist`. Only for tool.before gates (doc-density floor on .md writes, theatrical-claim block on bash).

## Verification
1. `omp ttsr test '<derailment phrase>' --source thinking --agent task` → rule fires.
2. Spawn trap subagent (task text invites scope-shrink) → response shows decomposition, transcript shows TTSR interrupt.
3. Thin-doc test: 30-line "ARCHITECTURE.md" write → Layer-3 throws if enabled.

## Gotchas
- models.yml modelOverrides has NO api/baseUrl keys (schema-verified) — endpoint reroute lives in ProviderOverride.baseUrl (provider level) or the proxy, never per-model override.
- New OMP sessions needed after rules/agents changes (discovery at session start).
- TTSR `--source thinking` is legal and evaluated (proven), so thinking-stream derailments ARE catchable.
- Whitelist/trigger exact-match gotcha: OMP wires `provider/model:effort` — strip prefix + suffix before matching (regex `replace(/^.*\//,"").replace(/:[a-z0-9_-]+$/,"")`).
