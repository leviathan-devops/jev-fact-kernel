JEV_ABIDE_CONTEXT_HANDOVER — FULL CONTEXT HANDOVER
================================
Paste into a local TUI in this order:

1. 00_HANDOVER/JEV_ABIDE_BEHAVIOR_POLICING_CONTEXT_HANDOVER.md
   Primary-agent memory. Rulings, freeze internals, dead paths.

2. 01_BINDING_SPEC/WarheadsAbide_Master_Blueprint_v1.md
   The only build spec. Law.

3. Optional short inject in 00_HANDOVER/ if context is tight.

4. Everything else is reference or negative example.
   02_SUPERSEDED_READ_ONLY — do not implement rejected drives.
   03_HOST_BIBLES — later depth only.
   04_ADJACENT — other products in the same workspace.

Conflict rule:
  BINDING wins on implementation detail.
  Handover wins on session rulings and named dead paths.
  Superseded specs are APIs + history.
Read order: 00_HANDOVER/PASTE_ORDER.txt. Second spec: the claim-gate spec JevClaimFirewall_Blueprint.md (root of the pack stage + 01).
